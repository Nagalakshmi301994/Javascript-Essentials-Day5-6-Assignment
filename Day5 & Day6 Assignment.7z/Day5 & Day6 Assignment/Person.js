let persons = [
    {
      name: "John",
      age: 22,
      city: "Madurai",
      salary: "30,000",
    },
    {
      name: "Conor",
      age: 34,
      city: "Salem",
      salary: "50,000",
    },
    {
      name: "Prabhu",
      age: 26,
      city: "Trichy",
      salary: "40,000",
    },
  ];
  
  function display(superarray) {
    let tabledata = "";
  
    superarray.forEach(function (persons, index) {
      let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${persons.name}</td>
      <td>${persons.age}</td>
      <td>${persons.city}</td>
      <td>${persons.salary}</td>
      <td>
      <button onclick='deletePersons(${index})'>delete</button>
      <button onclick='showModal(${index})'>update</button>
      </td>
      </tr>`;
  
      tabledata += currentrow;
    });
  
    document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
    //   document.getElementById("tdata").innerHTML = tabledata;
  }
  
  display(persons);
  
  function addnewmember(e) {
    e.preventDefault();
    let newperson = {};
    let name = document.getElementById("name").value;
    let age = document.getElementById("age").value;
    let city = document.getElementById("city").value;
    let salary = document.getElementById("salary").value;
    newperson.name = name;
    newperson.age = Number(age);
    newperson.city = city;
    newperson.salary = salary;
  
    persons.push(newperson);
  
    display(persons);
  
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
    document.getElementById("city").value = "";
    document.getElementById("salary").value = "";
  }
  
  function searchByName() {
    let searchValue = document.getElementById("searchName").value;
  
    let newdata = persons.filter(function (persons) {
      return (persons.name.toUpperCase().indexOf(searchValue.toUpperCase()) != -1);
    });
    display(newdata);

    let newdata1 = persons.filter(function (persons) {
        return (persons.city.toUpperCase().indexOf(searchValue.toUpperCase()) != -1);
      });
      display(newdata1);
  }
  
  
  function deletePersons(index) {
    persons.splice(index, 1);
    display(persons);
  }
  
  let updateIndex;
  
  function copyperson(index) {
    updateIndex = index;
    let superhero = persons[index];
  
    document.getElementById("upname").value = superhero.name;
    document.getElementById("upage").value = superhero.age;
    document.getElementById("upplanet").value = superhero.planet;
    document.getElementById("upheight").value = superhero.height;
  }
  
  function updatenames(e) {
    e.preventDefault();
    let supernames = persons[updateIndex];
    console.log(supernames);
    let name = document.getElementById("upname").value;
    let age = document.getElementById("upage").value;
    let city = document.getElementById("upcity").value;
    let salary = document.getElementById("upsalary").value;
    supernames.name = name;
    supernames.age = Number(age);
    supernames.city = city;
    supernames.salary = salary;
    console.log(supernames);
  
    display(persons);
  
    // code for hiding from anywhere
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "none";
  }
  
  function showModal(index) {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "block";
  
    copyperson(index);
  }
  
  function hideModal(event) {
    if (event.target.className == "modal") {
      let modal = document.getElementsByClassName("modal")[0];
      modal.style.display = "none";
    }
  }