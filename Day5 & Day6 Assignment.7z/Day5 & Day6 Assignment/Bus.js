let persons = [
    {
      name: "John",
      source: "Chennai",
      destination: "Madurai",
      number: 9068907998,
      passenger:"2",
    },
    {
        name: "Conor",
        source: "Salem",
        destination: "Namakkal",
        number: 9068907598,
        passenger:"1",
    },
    {
        name: "Prabhu",
        source: "Erode",
        destination: "Trichy",
        number: 9060907998,
        passenger:"3",
    },
  ];
  
  function display(superarray) {
    let tabledata = "";
  
    superarray.forEach(function (persons, index) {
      let currentrow = `<tr>
      <td>${index + 1}</td>
      <td>${persons.name}</td>
      <td>${persons.source}</td>
      <td>${persons.destination}</td>
      <td>${persons.number}</td>
      <td>${persons.passenger}</td>
      </tr>`;
  
      tabledata += currentrow;
    });
  
    document.getElementsByClassName("tdata")[0].innerHTML = tabledata;
    //   document.getElementById("tdata").innerHTML = tabledata;
  }
  
  display(persons);
  
  function addnewmember(e) {
    e.preventDefault();
    let newperson = {};
    let name = document.getElementById("name").value;
    let source = document.getElementById("source").value;
    let destination = document.getElementById("destination").value;
    let number = document.getElementById("number").value;
    let passenger = document.getElementById("passenger").value;
    newperson.name = name;
    newperson.source = source;
    newperson.destination = destination;
    newperson.number = number;
    newperson.passenger = Number(passenger);
  
    persons.push(newperson);
  
    display(persons);
  
    document.getElementById("name").value = "";
    document.getElementById("source").value = "";
    document.getElementById("destination").value = "";
    document.getElementById("number").value = "";
    document.getElementById("passenger").value = "";

  }
  
  function searchByName() {
    let searchValue = document.getElementById("searchName").value;
  
    let newdata = persons.filter(function (persons) {
      return (persons.source.toUpperCase().indexOf(searchValue.toUpperCase()) != -1);
    });
    display(newdata);

    let newdata1 = persons.filter(function (persons) {
        return (persons.destination.toUpperCase().indexOf(searchValue.toUpperCase()) != -1);
      });
      display(newdata1);
  }

  
  let updateIndex;
  
  function copyperson(index) {
    updateIndex = index;
    let superpersons = persons[index];
  
    document.getElementById("upname").value = superpersons.name;
    document.getElementById("upsource").value = superpersons.source;
    document.getElementById("updestination").value = superpersons.destination;
    document.getElementById("upnumber").value = superpersons.number;
    document.getElementById("uppassengerr").value = superpersons.passenger;

  }
  
  function showModal(index) {
    let modal = document.getElementsByClassName("modal")[0];
    modal.style.display = "block";
  
    copyperson(index);
  }
  
  function hideModal(event) {
    if (event.target.className == "modal") {
      let modal = document.getElementsByClassName("modal")[0];
      modal.style.display = "none";
    }
  }